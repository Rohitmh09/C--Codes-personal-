package com.example.menuebar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar t = findViewById(R.id.toolbar);
        setSupportActionBar(t);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolmenu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
       // return super.onOptionsItemSelected(item);

        int id = item.getItemId();

        if (id == R.id.mad)
        {
            Toast.makeText(this, "You selected MAD", Toast.LENGTH_SHORT).show();
        }
        if (id == R.id.coc)
        {
            Toast.makeText(this, "You selected coc", Toast.LENGTH_SHORT).show();
        }
        if (id == R.id.toc)
        {
            Toast.makeText(this, "You selected toc", Toast.LENGTH_SHORT).show();
        }
        return  true;
    }
}