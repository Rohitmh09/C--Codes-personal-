package com.example.databaseprogram;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Message;
import android.provider.ContactsContract;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText name, contact, dob;
    Button insert, update, delete, view,clear;
   SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        name = findViewById(R.id.name);
        contact = findViewById(R.id.contact);
        dob = findViewById(R.id.dob);
        insert = findViewById(R.id.btnInsert);
        update = findViewById(R.id.btnUpdate);
        delete = findViewById(R.id.btnDelete);
        view = findViewById(R.id.btnView);
        clear=findViewById(R.id.btnclear);
        db = openOrCreateDatabase("studentDB", Context.MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS student(name VARCHAR,contact VARCHAR,dob VARCHAR);");
    insert.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            {if(v==insert)
            {
                if(name.getText().toString().trim().length()==0||
                        contact.getText().toString().trim().length()==0||
                        dob.getText().toString().trim().length()==0)
                {
                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();

                }
                db.execSQL("INSERT INTO student VALUES('"+name.getText()+"','"+contact.getText()+"','"+dob.getText()+"');");
                Toast.makeText(MainActivity.this, "added", Toast.LENGTH_SHORT).show();
                name.setText("");
                contact.setText("");
                dob.setText("");

            }
            }
        }
    });
    view.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Cursor c=db.rawQuery("SELECT * FROM student WHERE name='"+name.getText()+"'",null);
        if(c.moveToFirst())
        {
            contact.setText(c.getString(1));
            dob.setText(c.getString(2));


        }
         c.close();
        }
    });
    update.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(v==update)
            {
                if(name.getText().toString().trim().length()==0)
                {
                    Toast.makeText(MainActivity.this, "PLS ENTERED NAME", Toast.LENGTH_SHORT).show();
                    }
                Cursor c=db.rawQuery("SELECT * FROM student WHERE name='"+name.getText()+"'",null);
                if(c.moveToFirst())
                {
                 db.execSQL("UPDATE student SET contact='"+contact.getText()+"',dob='"+dob.getText()+"'WHERE name='"+name.getText()+"'");
                    Toast.makeText(MainActivity.this, "RECORD UPDATED SUCCESSFULLY", Toast.LENGTH_SHORT).show();

                }
                else {
                    Toast.makeText(MainActivity.this, "INVALID NAME", Toast.LENGTH_SHORT).show();
                }
                name.setText("");
                contact.setText("");
                dob.setText("");

                c.close();
            }

        }
    });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (name.getText().toString().trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Please enter a name", Toast.LENGTH_SHORT).show();
                    return;
                }
                Cursor c = db.rawQuery("SELECT * FROM student WHERE name=?", new String[]{name.getText().toString()});
                if (c.moveToFirst()) {
                    db.execSQL("DELETE FROM student WHERE name=?", new String[]{name.getText().toString()});
                    Toast.makeText(MainActivity.this, "Record deleted successfully", Toast.LENGTH_SHORT).show();
                    clearFields();
                } else {
                    Toast.makeText(MainActivity.this, "Invalid name", Toast.LENGTH_SHORT).show();
                }
                c.close();
          }
        });

    clear.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            name.setText("");
            contact.setText("");
            dob.setText("");

        }
    });

    }

    private void clearFields() {
        name.setText("");
        contact.setText("");
        dob.setText("");
    }

     }